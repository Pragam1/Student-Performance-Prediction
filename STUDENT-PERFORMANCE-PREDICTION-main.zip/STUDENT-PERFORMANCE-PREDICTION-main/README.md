# StudentPerformancePrediction-ML
This is a simple machine learning project using classifiers for predicting factors which affect student grades, using data from CSV file


In this Project, a dataset which has students from nationalities, different grade levels and also soe determining factors like,
number of hands raised, nuber attendances, number of hours studied etc. is used, which is a CSV File.


And a few different classifiers and ML models have been used to get the most accurate predictions of which factors,
affect the marks of students.

A few visual aids like graphs and confusion matrix have been created, to show the results.
